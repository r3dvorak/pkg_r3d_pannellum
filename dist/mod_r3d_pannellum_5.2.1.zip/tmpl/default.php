<?php
/**
 * @package     Joomla.Module
 * @subpackage  mod_r3d_pannellum
 * @creation    2025-09-14
 * @author      Richard Dvorak, r3d.de
 * @copyright   Copyright (C) 2025 Richard Dvorak, https://r3d.de
 * @license     GNU GPL v3 or later (https://www.gnu.org/licenses/gpl-3.0.html)
 * @version     5.2.1
 * @file        modules/mod_r3d_pannellum/tmpl/default.php
 */

defined('_JEXEC') or die;

// This assumes $build is passed from mod_r3d_pannellum.php
if (!isset($build) || !is_array($build)) {
  echo '<div class="uk-alert uk-alert-danger">Module build error: $build missing</div>';
  return;
}
$id = $build['id'] ?? 'r3dpan_' . bin2hex(random_bytes(4));
$style = $build['style'] ?? 'width:100%;height:400px;';
$config = $build['config'] ?? [];

?>
<div id="<?php echo $id; ?>" style="<?php echo $style; ?>"></div>
<script>
  (function () {
    var cfg = <?php echo json_encode($config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
    function init() {
      if (window.pannellum && typeof pannellum.viewer === 'function') {
        pannellum.viewer('<?php echo $id; ?>', cfg);
      }
    }
    document.addEventListener('pannellum:ready', init);
  })();
</script>